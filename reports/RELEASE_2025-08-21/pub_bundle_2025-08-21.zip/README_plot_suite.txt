This folder contains publication-ready figures:
- pub_per_port_ci.png           : Per-port success with 95% CIs
- pub_forest_gain.png           : Forest plot of (Fair - Unbalanced) improvements (95% CI)
- pub_minority_bars.png         : Fairness uplift on minority ports (95% CI)
- pub_overall_macro.png         : Macro-average across ports with error bars
- pub_table_overview.csv        : Table of per-port metrics and gains
